"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ProductGrid } from "@/components/product-grid"
import { CategoryGrid } from "@/components/category-grid"
import { BannerCarousel } from "@/components/banner-carousel"
import { Cart } from "@/components/cart"
import { ChatWidget } from "@/components/chat-widget"
import { AdminLoginModal } from "@/components/admin-login-modal"
import { useStore } from "@/lib/store"

export default function HomePage() {
  const [showAdminModal, setShowAdminModal] = useState(false)
  const { products, categories, banners, loadInitialData } = useStore()

  useEffect(() => {
    loadInitialData()
  }, [loadInitialData])

  const featuredProducts = products.filter((p) => p.featured)
  const allProducts = products.filter((p) => p.stock > 0)

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <main>
        {/* Banner Section */}
        <section className="container mx-auto px-4 py-6">
          <BannerCarousel banners={banners} />
        </section>

        {/* Featured Products Section */}
        {featuredProducts.length > 0 && (
          <section className="py-12 bg-white">
            <div className="container mx-auto px-4">
              <ProductGrid products={featuredProducts} title="Os mais procurados" />
            </div>
          </section>
        )}

        {/* Categories Section */}
        <section id="categorias" className="py-12">
          <div className="container mx-auto px-4">
            <div className="text-center mb-8">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">Categorias</h2>
              <div className="w-20 h-1 bg-orange-500 mx-auto rounded-full"></div>
            </div>
            <CategoryGrid categories={categories} />
          </div>
        </section>

        {/* All Products Section */}
        <section id="produtos" className="py-12 bg-white">
          <div className="container mx-auto px-4">
            <ProductGrid products={allProducts} title="Todos os Produtos" />
          </div>
        </section>

        {/* About Section */}
        <section id="sobre" className="py-16 bg-gray-100">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">Sobre Nossa Loja</h2>
            <div className="w-20 h-1 bg-orange-500 mx-auto rounded-full mb-8"></div>
            <div className="max-w-3xl mx-auto">
              <p className="text-lg text-gray-600 leading-relaxed mb-6">
                Somos uma loja online dedicada a oferecer produtos de alta qualidade com os melhores preços do mercado.
                Nossa missão é proporcionar uma experiência de compra excepcional para nossos clientes.
              </p>
              <p className="text-gray-600">
                Entre em contato conosco pelo WhatsApp para tirar dúvidas, fazer pedidos ou conhecer mais sobre nossos
                produtos!
              </p>
            </div>
          </div>
        </section>
      </main>

      <Footer onAdminClick={() => setShowAdminModal(true)} />
      <Cart />
      <ChatWidget />

      <AdminLoginModal open={showAdminModal} onOpenChange={setShowAdminModal} />
    </div>
  )
}
