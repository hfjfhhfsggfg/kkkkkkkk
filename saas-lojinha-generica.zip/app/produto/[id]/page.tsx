"use client"

import { useState } from "react"
import { useParams } from "next/navigation"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ProductGallery } from "@/components/product-gallery"
import { Cart } from "@/components/cart"
import { ChatWidget } from "@/components/chat-widget"
import { AdminLoginModal } from "@/components/admin-login-modal"
import { ProductGrid } from "@/components/product-grid"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ChevronRight, Facebook, Twitter, Share2 } from "lucide-react"
import { useStore } from "@/lib/store"
import { formatPrice } from "@/lib/utils"

export default function ProductPage() {
  const params = useParams()
  const [showAdminModal, setShowAdminModal] = useState(false)
  const [quantity, setQuantity] = useState(1)
  const [selectedColor, setSelectedColor] = useState("")
  const [selectedSize, setSelectedSize] = useState("")
  const [selectedStorage, setSelectedStorage] = useState("")
  const [activeTab, setActiveTab] = useState("description")

  const { products, addToCart, storeConfig } = useStore()

  const product = products.find((p) => p.id === params.id)

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold text-gray-900">Produto não encontrado</h1>
        </div>
        <Footer onAdminClick={() => setShowAdminModal(true)} />
      </div>
    )
  }

  // Produtos relacionados da mesma categoria
  const relatedProducts = products
    .filter((p) => p.category === product.category && p.id !== product.id && p.stock > 0)
    .slice(0, 4)

  const handleAddToCart = () => {
    addToCart(product, quantity)
  }

  const handleWhatsAppPurchase = () => {
    const options = []
    if (selectedColor) options.push(`Cor: ${selectedColor}`)
    if (selectedSize) options.push(`Tamanho: ${selectedSize}`)
    if (selectedStorage) options.push(`Armazenamento: ${selectedStorage}`)

    const optionsText = options.length > 0 ? `\nOpções: ${options.join(", ")}` : ""
    const message = `Olá, quero comprar ${product.name}${optionsText}\nQuantidade: ${quantity}\nPreço: ${formatPrice(product.price)}`
    const whatsappUrl = `https://wa.me/${storeConfig.whatsapp}?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
  }

  const discountPercentage = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0

  const savings = product.originalPrice ? product.originalPrice - product.price : 0

  // Mock options - em produção viriam do produto
  const colorOptions = ["SPACE BLACK", "SILVER", "GOLD", "ROSE GOLD"]
  const sizeOptions = ["256GB", "512GB", "1TB"]
  const storageOptions = ["WIFI", "WIFI + CELLULAR"]

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <div className="container mx-auto px-4 py-4">
        {/* Breadcrumb - IGUAL AO LINE EXPRESS */}
        <nav className="flex items-center space-x-2 text-sm text-gray-600 mb-6">
          <span>Início</span>
          <ChevronRight className="w-4 h-4" />
          <span>{product.category}</span>
          <ChevronRight className="w-4 h-4" />
          <span className="text-gray-900">{product.name}</span>
        </nav>

        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          {/* Product Gallery */}
          <div>
            <ProductGallery images={product.images} />
          </div>

          {/* Product Info - IGUAL AO LINE EXPRESS */}
          <div className="space-y-6">
            {/* Título */}
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900 leading-tight">{product.name}</h1>
            </div>

            {/* Preços - IGUAL AO LINE EXPRESS */}
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-3">
                <span className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-yellow-600 to-yellow-500 bg-clip-text text-transparent">
                  {formatPrice(product.price)}
                </span>
                {product.originalPrice && (
                  <span className="text-xl text-gray-400 line-through">{formatPrice(product.originalPrice)}</span>
                )}
              </div>

              {savings > 0 && (
                <div className="flex items-center gap-3">
                  <p className="text-gray-700">
                    Economize: <span className="font-semibold text-green-600">{formatPrice(savings)}</span>
                  </p>
                  <Badge className="bg-gradient-to-r from-yellow-600 to-yellow-500 text-white font-bold">
                    {discountPercentage}% OFF
                  </Badge>
                </div>
              )}
            </div>

            {/* Opções de Cor - IGUAL AO LINE EXPRESS */}
            {colorOptions.length > 0 && (
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">
                  COR: <span className="font-normal">{selectedColor || colorOptions[0]}</span>
                </h3>
                <div className="flex flex-wrap gap-3">
                  {colorOptions.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`px-4 py-2 border-2 rounded-lg text-sm font-medium transition-colors ${
                        selectedColor === color || (!selectedColor && color === colorOptions[0])
                          ? "border-yellow-500 bg-yellow-50"
                          : "border-gray-300 hover:border-gray-400"
                      }`}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Opções de Tamanho - IGUAL AO LINE EXPRESS */}
            {sizeOptions.length > 0 && (
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">
                  TAMANHO: <span className="font-normal">{selectedSize || sizeOptions[0]}</span>
                </h3>
                <div className="flex flex-wrap gap-3">
                  {sizeOptions.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`px-4 py-2 border-2 rounded-lg text-sm font-medium transition-colors ${
                        selectedSize === size || (!selectedSize && size === sizeOptions[0])
                          ? "border-yellow-500 bg-yellow-50"
                          : "border-gray-300 hover:border-gray-400"
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Opções de Conectividade - IGUAL AO LINE EXPRESS */}
            {storageOptions.length > 0 && (
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">
                  FUNÇÃO CHIP: <span className="font-normal">{selectedStorage || storageOptions[0]}</span>
                </h3>
                <div className="flex flex-wrap gap-3">
                  {storageOptions.map((storage) => (
                    <button
                      key={storage}
                      onClick={() => setSelectedStorage(storage)}
                      className={`px-4 py-2 border-2 rounded-lg text-sm font-medium transition-colors ${
                        selectedStorage === storage || (!selectedStorage && storage === storageOptions[0])
                          ? "border-yellow-500 bg-yellow-50"
                          : "border-gray-300 hover:border-gray-400"
                      }`}
                    >
                      {storage}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantidade - IGUAL AO LINE EXPRESS */}
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">QUANTIDADE</h3>
              <div className="flex items-center">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-12 h-12 rounded-full bg-gradient-to-r from-yellow-600 to-yellow-500 text-white border-0 hover:from-yellow-700 hover:to-yellow-600"
                >
                  −
                </Button>
                <span className="mx-8 text-xl font-semibold w-8 text-center">{quantity}</span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                  className="w-12 h-12 rounded-full bg-gradient-to-r from-yellow-600 to-yellow-500 text-white border-0 hover:from-yellow-700 hover:to-yellow-600"
                >
                  +
                </Button>
              </div>
            </div>

            {/* Botão Comprar - IGUAL AO LINE EXPRESS */}
            {product.stock > 0 && (
              <Button
                onClick={handleWhatsAppPurchase}
                className="w-full h-14 bg-gradient-to-r from-yellow-600 to-yellow-500 hover:from-yellow-700 hover:to-yellow-600 text-white font-bold text-lg rounded-xl"
              >
                C O M P R A R
              </Button>
            )}
          </div>
        </div>

        {/* Tabs de Descrição - IGUAL AO LINE EXPRESS */}
        <div className="mb-8">
          <div className="flex border-b">
            <button
              onClick={() => setActiveTab("description")}
              className={`px-6 py-3 font-semibold border-b-2 transition-colors ${
                activeTab === "description"
                  ? "border-yellow-500 text-yellow-600"
                  : "border-transparent text-gray-600 hover:text-gray-900"
              }`}
            >
              DESCRIÇÃO
            </button>
            <button
              onClick={() => setActiveTab("purchase")}
              className={`px-6 py-3 font-semibold border-b-2 transition-colors ${
                activeTab === "purchase"
                  ? "border-yellow-500 text-yellow-600"
                  : "border-transparent text-gray-600 hover:text-gray-900"
              }`}
            >
              SOBRE SUA COMPRA
            </button>
          </div>

          <div className="py-6">
            {activeTab === "description" ? (
              <div className="prose max-w-none">
                <p className="text-gray-700 leading-relaxed mb-4">{product.description}</p>
                <p className="text-gray-700 leading-relaxed mb-4">Ficou com alguma dúvida?</p>
                <p className="text-gray-700 leading-relaxed">
                  <strong>Fale com um de nossos especialistas e veja qual é o melhor modelo para você!</strong>
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">PEDIDOS</h4>
                  <p className="text-gray-700">Faça pedidos e verifique a disponibilidade pelo nosso © WhatsApp!</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">COMPRE E CANCELE QUANDO QUISER</h4>
                  <p className="text-gray-700">Sua compra está protegida, cancele gratuitamente.</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Redes Sociais - IGUAL AO LINE EXPRESS */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="sm" className="p-2">
            <svg className="w-6 h-6 text-green-600" fill="currentColor" viewBox="0 0 24 24">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488z" />
            </svg>
          </Button>
          <Button variant="ghost" size="sm" className="p-2">
            <Facebook className="w-6 h-6 text-blue-600" />
          </Button>
          <Button variant="ghost" size="sm" className="p-2">
            <Twitter className="w-6 h-6 text-blue-400" />
          </Button>
          <Button variant="ghost" size="sm" className="p-2">
            <Share2 className="w-6 h-6 text-gray-600" />
          </Button>
        </div>

        {/* Produtos Relacionados - IGUAL AO LINE EXPRESS */}
        {relatedProducts.length > 0 && (
          <div className="border-t pt-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-6 text-center">
              Também temos essas opções ↓
            </h2>
            <ProductGrid products={relatedProducts} />
          </div>
        )}
      </div>

      <Footer onAdminClick={() => setShowAdminModal(true)} />
      <Cart />
      <ChatWidget />

      <AdminLoginModal open={showAdminModal} onOpenChange={setShowAdminModal} />
    </div>
  )
}
