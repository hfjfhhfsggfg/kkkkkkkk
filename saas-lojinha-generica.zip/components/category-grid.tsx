"use client"

import { useRef } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"
import type { Category } from "@/lib/types"
import {
  Shirt,
  Smartphone,
  Home,
  Sparkles,
  Package,
  ShoppingBag,
  Laptop,
  Headphones,
  Watch,
  Camera,
} from "lucide-react"

interface CategoryGridProps {
  categories: Category[]
}

const categoryIcons = {
  Moda: Shirt,
  Eletrônicos: Smartphone,
  Smartphones: Smartphone,
  Notebooks: Laptop,
  Acessórios: Headphones,
  Casa: Home,
  Beleza: Sparkles,
  Relógios: Watch,
  Câmeras: Camera,
  Outros: Package,
  default: ShoppingBag,
}

const categoryColors = {
  Moda: "from-pink-500 to-rose-500",
  Eletrônicos: "from-blue-500 to-indigo-500",
  Smartphones: "from-green-500 to-emerald-500",
  Notebooks: "from-purple-500 to-violet-500",
  Acessórios: "from-orange-500 to-amber-500",
  Casa: "from-teal-500 to-cyan-500",
  Beleza: "from-pink-400 to-rose-400",
  Relógios: "from-gray-600 to-slate-600",
  Câmeras: "from-red-500 to-pink-500",
  Outros: "from-gray-500 to-gray-600",
  default: "from-yellow-600 to-yellow-500",
}

export function CategoryGrid({ categories }: CategoryGridProps) {
  const scrollRef = useRef<HTMLDivElement>(null)

  const scrollLeft = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: -300, behavior: "smooth" })
    }
  }

  const scrollRight = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: 300, behavior: "smooth" })
    }
  }

  return (
    <div className="relative">
      {/* Botões de navegação */}
      <Button
        variant="ghost"
        size="sm"
        onClick={scrollLeft}
        className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white/90 hover:bg-white shadow-lg rounded-full w-12 h-12 p-0 border"
      >
        <ChevronLeft className="w-5 h-5" />
      </Button>

      <Button
        variant="ghost"
        size="sm"
        onClick={scrollRight}
        className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white/90 hover:bg-white shadow-lg rounded-full w-12 h-12 p-0 border"
      >
        <ChevronRight className="w-5 h-5" />
      </Button>

      {/* Carrossel horizontal de categorias */}
      <div
        ref={scrollRef}
        className="flex gap-6 overflow-x-auto scrollbar-hide pb-4 px-12"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {categories.map((category) => {
          const IconComponent = categoryIcons[category.name as keyof typeof categoryIcons] || categoryIcons.default
          const colorClass = categoryColors[category.name as keyof typeof categoryColors] || categoryColors.default

          return (
            <div
              key={category.id}
              className="bg-white rounded-xl p-6 text-center hover:shadow-xl transition-all duration-300 cursor-pointer border border-gray-100 min-w-[180px] flex-shrink-0 group hover:-translate-y-1"
            >
              <div
                className={`w-16 h-16 bg-gradient-to-r ${colorClass} rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}
              >
                <IconComponent className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-semibold text-gray-900 text-base mb-2 group-hover:text-gray-700 transition-colors">
                {category.name}
              </h3>
              <Badge
                variant="secondary"
                className="text-xs bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors"
              >
                {category.productCount} produtos
              </Badge>
            </div>
          )
        })}
      </div>
    </div>
  )
}
