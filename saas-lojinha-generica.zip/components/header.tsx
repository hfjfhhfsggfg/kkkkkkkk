"use client"

import type React from "react"
import { useState } from "react"
import Link from "next/link"
import { Search, Menu, X, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { CartButton } from "@/components/cart-button"
import { useStore } from "@/lib/store"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const { storeConfig, searchProducts } = useStore()

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      searchProducts(searchQuery)
    }
  }

  const handleMenuClick = () => {
    setIsMenuOpen(false)
  }

  const handleContactClick = () => {
    const message = "Olá! Gostaria de mais informações sobre a loja."
    const whatsappUrl = `https://wa.me/${storeConfig.whatsapp}?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
    setIsMenuOpen(false)
  }

  return (
    <>
      {/* Top Banner */}
      <div className="bg-gray-800 text-white text-center py-2 px-4">
        <p className="text-sm font-medium">PARCELAMENTO EM ATÉ 12X NO CARTÃO (VERIFIQUE EM NOSSO WHATSAPP)</p>
      </div>

      <header className="bg-white shadow-sm border-b sticky top-0 z-30">
        <div className="container mx-auto px-4">
          {/* Main Header */}
          <div className="flex items-center justify-between py-4">
            {/* Menu Mobile */}
            <Button variant="ghost" size="sm" className="lg:hidden p-2" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </Button>

            {/* Logo CENTRALIZADA - IGUAL AO LINE EXPRESS */}
            <div className="flex-1 flex justify-center lg:justify-center">
              <Link href="/" className="flex items-center" onClick={handleMenuClick}>
                <div className="text-center">
                  <div className="flex items-center justify-center mb-1">
                    <div className="w-8 h-8 bg-gradient-to-r from-yellow-600 to-yellow-500 rounded-full flex items-center justify-center mr-2">
                      <span className="text-white font-bold text-sm">T</span>
                    </div>
                    <h1 className="text-2xl font-bold bg-gradient-to-r from-yellow-600 to-yellow-500 bg-clip-text text-transparent">
                      {storeConfig.name}
                    </h1>
                  </div>
                  <p className="text-xs text-gray-600 hidden sm:block italic">{storeConfig.slogan}</p>
                </div>
              </Link>
            </div>

            {/* Cart */}
            <div className="flex items-center">
              <CartButton />
            </div>
          </div>

          {/* Navigation - Desktop */}
          <nav className="hidden lg:block pb-4 border-t pt-4">
            <div className="flex items-center justify-center space-x-8">
              <Link href="/" className="text-gray-700 hover:text-yellow-600 font-medium transition-colors">
                Home
              </Link>
              <Link href="#produtos" className="text-gray-700 hover:text-yellow-600 font-medium transition-colors">
                Produtos
              </Link>
              <Link href="#categorias" className="text-gray-700 hover:text-yellow-600 font-medium transition-colors">
                Categorias
              </Link>
              <Link href="#sobre" className="text-gray-700 hover:text-yellow-600 font-medium transition-colors">
                Sobre
              </Link>
              <Button
                variant="ghost"
                className="text-gray-700 hover:text-yellow-600 font-medium p-0 h-auto"
                onClick={handleContactClick}
              >
                Contato
              </Button>
            </div>
          </nav>

          {/* Search Bar - Desktop */}
          <div className="hidden lg:flex justify-center pb-4">
            <form onSubmit={handleSearch} className="flex w-full max-w-md">
              <Input
                type="text"
                placeholder="Buscar produtos..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="rounded-r-none"
              />
              <Button
                type="submit"
                className="rounded-l-none bg-gradient-to-r from-yellow-600 to-yellow-500 hover:from-yellow-700 hover:to-yellow-600"
              >
                <Search className="w-4 h-4" />
              </Button>
            </form>
          </div>

          {/* Mobile Menu */}
          {isMenuOpen && (
            <div className="lg:hidden absolute top-full left-0 right-0 bg-white border-b shadow-lg z-40">
              <nav className="p-4 space-y-4">
                <Link
                  href="/"
                  className="block text-gray-700 hover:text-yellow-600 font-medium py-2 transition-colors"
                  onClick={handleMenuClick}
                >
                  Home
                </Link>
                <Link
                  href="#produtos"
                  className="block text-gray-700 hover:text-yellow-600 font-medium py-2 transition-colors"
                  onClick={handleMenuClick}
                >
                  Produtos
                </Link>
                <Link
                  href="#categorias"
                  className="block text-gray-700 hover:text-yellow-600 font-medium py-2 transition-colors"
                  onClick={handleMenuClick}
                >
                  Categorias
                </Link>
                <Link
                  href="#sobre"
                  className="block text-gray-700 hover:text-yellow-600 font-medium py-2 transition-colors"
                  onClick={handleMenuClick}
                >
                  Sobre
                </Link>
                <Button
                  variant="ghost"
                  className="block w-full text-left text-gray-700 hover:text-yellow-600 font-medium py-2 px-0 h-auto justify-start"
                  onClick={handleContactClick}
                >
                  <Phone className="w-4 h-4 mr-2" />
                  Contato via WhatsApp
                </Button>

                {/* Mobile Search */}
                <div className="pt-4 border-t">
                  <form onSubmit={handleSearch} className="flex">
                    <Input
                      type="text"
                      placeholder="Buscar produtos..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="rounded-r-none"
                    />
                    <Button type="submit" className="rounded-l-none bg-gradient-to-r from-yellow-600 to-yellow-500">
                      <Search className="w-4 h-4" />
                    </Button>
                  </form>
                </div>
              </nav>
            </div>
          )}
        </div>
      </header>
    </>
  )
}
