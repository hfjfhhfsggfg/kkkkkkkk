"use client"

import { X, Plus, Minus, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useStore } from "@/lib/store"
import { formatPrice } from "@/lib/utils"
import Image from "next/image"
import { useState } from "react"

export function Cart() {
  const { cart, isCartOpen, toggleCart, updateCartItemQuantity, removeFromCart, storeConfig } = useStore()

  const [couponCode, setCouponCode] = useState("")

  const total = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0)

  const handleWhatsAppCheckout = () => {
    const items = cart
      .map((item) => `${item.product.name} (${item.quantity}x) - ${formatPrice(item.product.price * item.quantity)}`)
      .join("\n")

    const message = `Olá, quero finalizar minha compra da lojinha ${storeConfig.name}:\n\n${items}\n\nTotal: ${formatPrice(total)}`
    const whatsappUrl = `https://wa.me/${storeConfig.whatsapp}?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
  }

  if (!isCartOpen) return null

  return (
    <div className="fixed inset-0 z-50 bg-black/50" onClick={toggleCart}>
      <div
        className="fixed right-0 top-0 h-full w-full max-w-md bg-white shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b">
            <h2 className="text-lg font-semibold">Carrinho de Compras</h2>
            <Button variant="ghost" size="sm" onClick={toggleCart}>
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Cart Items */}
          <div className="flex-1 overflow-y-auto p-4">
            {cart.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500">Seu carrinho está vazio</p>
              </div>
            ) : (
              <div className="space-y-4">
                {cart.map((item) => (
                  <div key={item.product.id} className="flex gap-3 bg-gray-50 rounded-lg p-3">
                    <div className="relative w-16 h-16 rounded-md overflow-hidden">
                      <Image
                        src={item.product.images[0] || "/placeholder.svg?height=64&width=64"}
                        alt={item.product.name}
                        fill
                        className="object-cover"
                      />
                    </div>

                    <div className="flex-1">
                      <h3 className="font-medium text-sm">{item.product.name}</h3>
                      <p className="text-green-600 font-semibold">{formatPrice(item.product.price)}</p>

                      <div className="flex items-center gap-2 mt-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => updateCartItemQuantity(item.product.id, item.quantity - 1)}
                        >
                          <Minus className="w-3 h-3" />
                        </Button>
                        <span className="w-8 text-center text-sm">{item.quantity}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => updateCartItemQuantity(item.product.id, item.quantity + 1)}
                        >
                          <Plus className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeFromCart(item.product.id)}
                          className="ml-auto text-red-500 hover:text-red-700"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          {cart.length > 0 && (
            <div className="border-t p-4 space-y-4">
              {/* Coupon */}
              <div className="flex gap-2">
                <Input
                  placeholder="Código do cupom"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                />
                <Button variant="outline">Aplicar</Button>
              </div>

              {/* Total */}
              <div className="flex justify-between items-center text-lg font-semibold">
                <span>Total:</span>
                <span className="text-green-600">{formatPrice(total)}</span>
              </div>

              {/* Checkout Button */}
              <Button className="w-full bg-green-600 hover:bg-green-700" onClick={handleWhatsAppCheckout}>
                <MessageCircle className="w-4 h-4 mr-2" />
                Finalizar via WhatsApp
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
