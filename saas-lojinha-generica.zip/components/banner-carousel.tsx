"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"
import type { Banner } from "@/lib/types"

interface BannerCarouselProps {
  banners: Banner[]
}

export function BannerCarousel({ banners }: BannerCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0)

  useEffect(() => {
    if (banners.length === 0) return

    const timer = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex === banners.length - 1 ? 0 : prevIndex + 1))
    }, 5000)

    return () => clearInterval(timer)
  }, [banners.length])

  const goToPrevious = () => {
    setCurrentIndex(currentIndex === 0 ? banners.length - 1 : currentIndex - 1)
  }

  const goToNext = () => {
    setCurrentIndex(currentIndex === banners.length - 1 ? 0 : currentIndex + 1)
  }

  if (banners.length === 0) return null

  const currentBanner = banners[currentIndex]

  return (
    <div className="relative rounded-lg overflow-hidden mb-8">
      <div className="relative h-64 md:h-80 lg:h-96">
        <Image
          src={currentBanner.image || "/placeholder.svg?height=400&width=800"}
          alt={currentBanner.title || "Banner"}
          fill
          className="object-cover"
          priority
        />

        {/* Overlay apenas se tiver texto */}
        {(currentBanner.title || currentBanner.description) && <div className="absolute inset-0 bg-black/40" />}

        {/* Content - só aparece se tiver texto */}
        {(currentBanner.title || currentBanner.description || currentBanner.link) && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center text-white px-4 max-w-4xl">
              {currentBanner.title && (
                <h2 className="text-2xl md:text-4xl lg:text-5xl font-bold mb-4">{currentBanner.title}</h2>
              )}
              {currentBanner.description && (
                <p className="text-lg md:text-xl mb-6 opacity-90">{currentBanner.description}</p>
              )}
              {currentBanner.link && (
                <Link href={currentBanner.link}>
                  <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                    {currentBanner.buttonText || "Ver Mais"}
                  </Button>
                </Link>
              )}
            </div>
          </div>
        )}

        {/* Navigation Buttons */}
        {banners.length > 1 && (
          <>
            <Button
              variant="ghost"
              size="sm"
              className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/20 hover:bg-white/30 text-white"
              onClick={goToPrevious}
            >
              <ChevronLeft className="w-6 h-6" />
            </Button>

            <Button
              variant="ghost"
              size="sm"
              className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/20 hover:bg-white/30 text-white"
              onClick={goToNext}
            >
              <ChevronRight className="w-6 h-6" />
            </Button>
          </>
        )}

        {/* Indicators */}
        {banners.length > 1 && (
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
            {banners.map((_, index) => (
              <button
                key={index}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === currentIndex ? "bg-white" : "bg-white/50"
                }`}
                onClick={() => setCurrentIndex(index)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
