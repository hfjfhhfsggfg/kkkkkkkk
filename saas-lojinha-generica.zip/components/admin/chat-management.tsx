"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Send, MessageCircle, User, Clock, Phone, RefreshCw } from "lucide-react"
import { localDB, type ChatConversation, type ChatMessage } from "@/lib/local-storage"

export function ChatManagement() {
  const [selectedChat, setSelectedChat] = useState<string | null>(null)
  const [messageInput, setMessageInput] = useState("")
  const [conversations, setConversations] = useState<ChatConversation[]>([])
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [isLoading, setIsLoading] = useState(false)

  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Scroll para última mensagem
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // Carregar conversas
  useEffect(() => {
    loadConversations()
  }, [])

  // Auto-refresh a cada 5 segundos para simular tempo real
  useEffect(() => {
    const interval = setInterval(() => {
      loadConversations()
      if (selectedChat) {
        loadMessages(selectedChat)
      }
    }, 5000)

    return () => clearInterval(interval)
  }, [selectedChat])

  const loadConversations = () => {
    const allConversations = localDB.getConversations()

    // Calcular mensagens não lidas para cada conversa
    const conversationsWithUnread = allConversations.map((conv) => ({
      ...conv,
      unreadCount: localDB.getUnreadCount(conv.id),
    }))

    // Ordenar por última mensagem
    conversationsWithUnread.sort((a, b) => new Date(b.lastMessageAt).getTime() - new Date(a.lastMessageAt).getTime())

    setConversations(conversationsWithUnread as any)
  }

  const loadMessages = (conversationId: string) => {
    const conversationMessages = localDB.getMessages(conversationId)
    setMessages(conversationMessages)

    // Marcar todas as mensagens do cliente como lidas
    conversationMessages.forEach((msg) => {
      if (msg.isFromCustomer && !msg.readByAdmin) {
        localDB.updateMessage(msg.id, { readByAdmin: true })
      }
    })
  }

  const handleSelectChat = (conversationId: string) => {
    setSelectedChat(conversationId)
    loadMessages(conversationId)
  }

  const handleSendMessage = () => {
    if (!messageInput.trim() || !selectedChat || isLoading) return

    setIsLoading(true)

    try {
      const message: ChatMessage = {
        id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
        conversationId: selectedChat,
        message: messageInput,
        isFromCustomer: false,
        senderName: "Atendente",
        timestamp: new Date().toISOString(),
        readByAdmin: true,
        readByCustomer: false,
      }

      localDB.saveMessage(message)

      // Atualizar conversa
      const conversations = localDB.getConversations()
      const conversation = conversations.find((c) => c.id === selectedChat)
      if (conversation) {
        const updatedConversation = {
          ...conversation,
          lastMessageAt: new Date().toISOString(),
        }
        localDB.saveConversation(updatedConversation)
      }

      setMessages((prev) => [...prev, message])
      setMessageInput("")
      loadConversations()
    } catch (error) {
      console.error("Erro ao enviar mensagem:", error)
      alert("Erro ao enviar mensagem. Tente novamente.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleWhatsAppOpen = (conversation: ChatConversation) => {
    const message = `Olá ${conversation.customerName}, como posso ajudar?`
    const phone = conversation.customerPhone || "5511999999999"
    const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
  }

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  const selectedConversation = conversations.find((c) => c.id === selectedChat)
  const totalUnread = conversations.reduce((sum, conv) => sum + ((conv as any).unreadCount || 0), 0)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Gerenciar Chat</h2>
          <p className="text-gray-600">Converse com seus clientes (dados salvos localmente)</p>
        </div>
        <Button variant="outline" onClick={loadConversations}>
          <RefreshCw className="w-4 h-4 mr-2" />
          Atualizar
        </Button>
      </div>

      <div className="grid lg:grid-cols-3 gap-6 h-[600px]">
        {/* Chat List */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Conversas
              <Badge variant="secondary">{totalUnread} não lidas</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="space-y-1 max-h-[500px] overflow-y-auto">
              {conversations.length === 0 ? (
                <div className="p-4 text-center text-gray-500">
                  <MessageCircle className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">Nenhuma conversa ainda</p>
                </div>
              ) : (
                conversations.map((conversation) => (
                  <div
                    key={conversation.id}
                    className={`p-4 cursor-pointer hover:bg-gray-50 border-b transition-colors ${
                      selectedChat === conversation.id ? "bg-blue-50 border-blue-200" : ""
                    }`}
                    onClick={() => handleSelectChat(conversation.id)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center">
                        <User className="w-4 h-4 mr-2 text-gray-500" />
                        <h3 className="font-medium text-sm">👤 {conversation.customerName}</h3>
                      </div>
                      {(conversation as any).unreadCount > 0 && (
                        <Badge className="bg-red-500 text-white text-xs">{(conversation as any).unreadCount}</Badge>
                      )}
                    </div>

                    {conversation.customerPhone && (
                      <div className="flex items-center text-xs text-gray-500 mb-1">
                        <Phone className="w-3 h-3 mr-1" />
                        {conversation.customerPhone}
                      </div>
                    )}

                    <div className="flex items-center text-xs text-gray-400">
                      <Clock className="w-3 h-3 mr-1" />
                      {formatDate(conversation.lastMessageAt)} às {formatTime(conversation.lastMessageAt)}
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* Chat Window */}
        <Card className="lg:col-span-2">
          {selectedConversation ? (
            <>
              <CardHeader className="border-b">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center">
                      <User className="w-5 h-5 mr-2" />
                      {selectedConversation.customerName}
                    </CardTitle>
                    {selectedConversation.customerPhone && (
                      <p className="text-sm text-gray-600 mt-1">
                        <Phone className="w-4 h-4 inline mr-1" />
                        {selectedConversation.customerPhone}
                      </p>
                    )}
                  </div>
                  <Button variant="outline" size="sm" onClick={() => handleWhatsAppOpen(selectedConversation)}>
                    <MessageCircle className="w-4 h-4 mr-2" />
                    WhatsApp
                  </Button>
                </div>
              </CardHeader>

              <CardContent className="flex flex-col h-[400px] p-0">
                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.length === 0 ? (
                    <div className="text-center text-gray-500 py-8">
                      <MessageCircle className="w-8 h-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">Nenhuma mensagem ainda</p>
                    </div>
                  ) : (
                    messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${message.isFromCustomer ? "justify-start" : "justify-end"}`}
                      >
                        <div
                          className={`max-w-xs px-4 py-2 rounded-lg ${
                            message.isFromCustomer ? "bg-gray-100 text-gray-900" : "bg-blue-600 text-white"
                          }`}
                        >
                          <p className="text-sm">{message.message}</p>
                          <div className="flex items-center justify-between mt-1">
                            <p className={`text-xs ${message.isFromCustomer ? "text-gray-500" : "text-blue-100"}`}>
                              {formatTime(message.timestamp)}
                            </p>
                            {!message.isFromCustomer && (
                              <span className={`text-xs ${message.readByCustomer ? "text-blue-200" : "text-blue-300"}`}>
                                {message.readByCustomer ? "✓✓" : "✓"}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* Message Input */}
                <div className="border-t p-4">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Digite sua resposta..."
                      value={messageInput}
                      onChange={(e) => setMessageInput(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                      disabled={isLoading}
                    />
                    <Button onClick={handleSendMessage} disabled={isLoading || !messageInput.trim()}>
                      {isLoading ? "..." : <Send className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </>
          ) : (
            <CardContent className="flex items-center justify-center h-full">
              <div className="text-center text-gray-500">
                <MessageCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Selecione uma conversa para começar</p>
              </div>
            </CardContent>
          )}
        </Card>
      </div>
    </div>
  )
}
