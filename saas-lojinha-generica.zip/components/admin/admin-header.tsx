"use client"

import { Button } from "@/components/ui/button"
import { LogOut, Bell } from "lucide-react"
import { useStore } from "@/lib/store"
import { useRouter } from "next/navigation"

export function AdminHeader() {
  const { logout, storeConfig } = useStore()
  const router = useRouter()

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  return (
    <header className="bg-white border-b px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-gray-900">Painel Administrativo - {storeConfig.name}</h1>
          <p className="text-sm text-gray-600">Gerencie sua loja online</p>
        </div>

        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm">
            <Bell className="w-4 h-4" />
          </Button>

          <Button variant="outline" size="sm" onClick={handleLogout}>
            <LogOut className="w-4 h-4 mr-2" />
            Sair
          </Button>
        </div>
      </div>
    </header>
  )
}
