"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { useStore } from "@/lib/store"

export function StoreSettings() {
  const { storeConfig, updateStoreConfig } = useStore()
  const [formData, setFormData] = useState({
    whatsapp: storeConfig.whatsapp,
    email: storeConfig.email,
    returnPolicy: storeConfig.returnPolicy,
    paymentMethods: storeConfig.paymentMethods,
    emailNotifications: storeConfig.emailNotifications,
    couponCode: "",
    couponDiscount: "",
    couponExpiry: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    updateStoreConfig({
      ...storeConfig,
      whatsapp: formData.whatsapp,
      email: formData.email,
      returnPolicy: formData.returnPolicy,
      paymentMethods: formData.paymentMethods,
      emailNotifications: formData.emailNotifications,
    })

    alert("Configurações salvas com sucesso!")
  }

  const handleCreateCoupon = () => {
    if (!formData.couponCode || !formData.couponDiscount) {
      alert("Preencha o código e desconto do cupom")
      return
    }

    // Here you would save the coupon to your store
    alert(`Cupom ${formData.couponCode} criado com ${formData.couponDiscount}% de desconto!`)
    setFormData((prev) => ({
      ...prev,
      couponCode: "",
      couponDiscount: "",
      couponExpiry: "",
    }))
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Configurações Gerais</h2>
        <p className="text-gray-600">Configure as opções gerais da sua loja</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Contact Info */}
        <Card>
          <CardHeader>
            <CardTitle>Informações de Contato</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="whatsapp">WhatsApp (com código do país)</Label>
              <Input
                id="whatsapp"
                value={formData.whatsapp}
                onChange={(e) => setFormData((prev) => ({ ...prev, whatsapp: e.target.value }))}
                placeholder="5511999999999"
                required
              />
              <p className="text-sm text-gray-500 mt-1">Exemplo: 5511999999999 (Brasil + DDD + número)</p>
            </div>

            <div>
              <Label htmlFor="email">E-mail</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                placeholder="contato@sualojainha.com"
              />
            </div>
          </CardContent>
        </Card>

        {/* Policies */}
        <Card>
          <CardHeader>
            <CardTitle>Políticas da Loja</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="returnPolicy">Política de Trocas e Devoluções</Label>
              <Textarea
                id="returnPolicy"
                value={formData.returnPolicy}
                onChange={(e) => setFormData((prev) => ({ ...prev, returnPolicy: e.target.value }))}
                rows={4}
                placeholder="Descreva sua política de trocas e devoluções..."
              />
            </div>

            <div>
              <Label htmlFor="paymentMethods">Formas de Pagamento Aceitas</Label>
              <Textarea
                id="paymentMethods"
                value={formData.paymentMethods}
                onChange={(e) => setFormData((prev) => ({ ...prev, paymentMethods: e.target.value }))}
                rows={3}
                placeholder="Ex: Pix, Boleto, Cartão de Crédito..."
              />
            </div>
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card>
          <CardHeader>
            <CardTitle>Notificações</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              <Switch
                id="emailNotifications"
                checked={formData.emailNotifications}
                onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, emailNotifications: checked }))}
              />
              <Label htmlFor="emailNotifications">Receber notificações por e-mail</Label>
            </div>
          </CardContent>
        </Card>

        <Button type="submit" className="w-full">
          Salvar Configurações
        </Button>
      </form>

      {/* Coupon Management */}
      <Card>
        <CardHeader>
          <CardTitle>Gerenciar Cupons de Desconto</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label htmlFor="couponCode">Código do Cupom</Label>
              <Input
                id="couponCode"
                value={formData.couponCode}
                onChange={(e) => setFormData((prev) => ({ ...prev, couponCode: e.target.value }))}
                placeholder="DESCONTO10"
              />
            </div>

            <div>
              <Label htmlFor="couponDiscount">Desconto (%)</Label>
              <Input
                id="couponDiscount"
                type="number"
                value={formData.couponDiscount}
                onChange={(e) => setFormData((prev) => ({ ...prev, couponDiscount: e.target.value }))}
                placeholder="10"
              />
            </div>

            <div>
              <Label htmlFor="couponExpiry">Data de Expiração</Label>
              <Input
                id="couponExpiry"
                type="date"
                value={formData.couponExpiry}
                onChange={(e) => setFormData((prev) => ({ ...prev, couponExpiry: e.target.value }))}
              />
            </div>
          </div>

          <Button onClick={handleCreateCoupon} className="w-full">
            Criar Cupom
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
