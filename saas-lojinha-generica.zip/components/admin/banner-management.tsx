"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Plus, Edit, Trash2, GripVertical } from "lucide-react"
import { useStore } from "@/lib/store"
import type { Banner } from "@/lib/types"
import Image from "next/image"

export function BannerManagement() {
  const [showForm, setShowForm] = useState(false)
  const [editingBanner, setEditingBanner] = useState<Banner | null>(null)
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    image: "",
    link: "",
    buttonText: "",
  })

  const { banners, addBanner, updateBanner, deleteBanner } = useStore()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const bannerData = {
      title: formData.title,
      description: formData.description,
      image: formData.image,
      link: formData.link,
      buttonText: formData.buttonText,
      order: banners.length,
    }

    if (editingBanner) {
      updateBanner(editingBanner.id, bannerData)
    } else {
      addBanner(bannerData)
    }

    handleCloseForm()
  }

  const handleEdit = (banner: Banner) => {
    setEditingBanner(banner)
    setFormData({
      title: banner.title,
      description: banner.description,
      image: banner.image,
      link: banner.link || "",
      buttonText: banner.buttonText || "",
    })
    setShowForm(true)
  }

  const handleDelete = (bannerId: string) => {
    if (confirm("Tem certeza que deseja excluir este banner?")) {
      deleteBanner(bannerId)
    }
  }

  const handleCloseForm = () => {
    setShowForm(false)
    setEditingBanner(null)
    setFormData({
      title: "",
      description: "",
      image: "",
      link: "",
      buttonText: "",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gerenciar Banners</h2>
          <p className="text-gray-600">Crie e gerencie os banners do carrossel principal</p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Novo Banner
        </Button>
      </div>

      {/* Banners List */}
      <Card>
        <CardHeader>
          <CardTitle>Banners ({banners.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {banners.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">Nenhum banner criado ainda</p>
            </div>
          ) : (
            <div className="space-y-4">
              {banners.map((banner) => (
                <div key={banner.id} className="flex items-center gap-4 p-4 border rounded-lg">
                  <div className="cursor-move">
                    <GripVertical className="w-5 h-5 text-gray-400" />
                  </div>

                  <div className="relative w-20 h-12 rounded-md overflow-hidden bg-gray-100">
                    <Image
                      src={banner.image || "/placeholder.svg?height=48&width=80"}
                      alt={banner.title}
                      fill
                      className="object-cover"
                    />
                  </div>

                  <div className="flex-1">
                    <h3 className="font-medium">{banner.title}</h3>
                    <p className="text-sm text-gray-600 line-clamp-1">{banner.description}</p>
                    {banner.link && <p className="text-xs text-blue-600">Link: {banner.link}</p>}
                  </div>

                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" onClick={() => handleEdit(banner)}>
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(banner.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Banner Form Modal */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingBanner ? "Editar Banner" : "Novo Banner"}</DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="title">Título do Banner (opcional)</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData((prev) => ({ ...prev, title: e.target.value }))}
                placeholder="Deixe vazio se não quiser texto"
              />
            </div>

            <div>
              <Label htmlFor="description">Descrição (opcional)</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
                rows={3}
                placeholder="Deixe vazio se não quiser texto"
              />
            </div>

            <div>
              <Label htmlFor="image">URL da Imagem</Label>
              <Input
                id="image"
                value={formData.image}
                onChange={(e) => setFormData((prev) => ({ ...prev, image: e.target.value }))}
                placeholder="https://exemplo.com/imagem.jpg"
                required
              />
            </div>

            <div>
              <Label htmlFor="link">Link de Redirecionamento (opcional)</Label>
              <Input
                id="link"
                value={formData.link}
                onChange={(e) => setFormData((prev) => ({ ...prev, link: e.target.value }))}
                placeholder="/produto/123 ou https://exemplo.com"
              />
            </div>

            <div>
              <Label htmlFor="buttonText">Texto do Botão (opcional)</Label>
              <Input
                id="buttonText"
                value={formData.buttonText}
                onChange={(e) => setFormData((prev) => ({ ...prev, buttonText: e.target.value }))}
                placeholder="Ver Mais"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-4">
              <Button type="button" variant="outline" onClick={handleCloseForm}>
                Cancelar
              </Button>
              <Button type="submit">{editingBanner ? "Atualizar" : "Criar"} Banner</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
