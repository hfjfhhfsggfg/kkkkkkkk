"use client"

import { useState } from "react"
import { AdminSidebar } from "./admin-sidebar"
import { AdminHeader } from "./admin-header"
import { DashboardOverview } from "./dashboard-overview"
import { BannerManagement } from "./banner-management"
import { ProductManagement } from "./product-management"
import { OrderManagement } from "./order-management"
import { ChatManagement } from "./chat-management"
import { StoreCustomization } from "./store-customization"
import { StoreSettings } from "./store-settings"
import { Analytics } from "./analytics"

export function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("dashboard")

  const renderContent = () => {
    switch (activeTab) {
      case "dashboard":
        return <DashboardOverview />
      case "banners":
        return <BannerManagement />
      case "products":
        return <ProductManagement />
      case "orders":
        return <OrderManagement />
      case "chat":
        return <ChatManagement />
      case "customization":
        return <StoreCustomization />
      case "settings":
        return <StoreSettings />
      case "analytics":
        return <Analytics />
      default:
        return <DashboardOverview />
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader />
      <div className="flex">
        <AdminSidebar activeTab={activeTab} onTabChange={setActiveTab} />
        <main className="flex-1 p-4 lg:p-6 lg:ml-0">
          <div className="max-w-7xl mx-auto">{renderContent()}</div>
        </main>
      </div>
    </div>
  )
}
