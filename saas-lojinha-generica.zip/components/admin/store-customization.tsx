"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useStore } from "@/lib/store"

export function StoreCustomization() {
  const { storeConfig, updateStoreConfig } = useStore()
  const [formData, setFormData] = useState({
    name: storeConfig.name,
    slogan: storeConfig.slogan,
    description: storeConfig.description,
    logo: storeConfig.logo,
    primaryColor: storeConfig.primaryColor,
    secondaryColor: storeConfig.secondaryColor,
    facebook: storeConfig.socialMedia.facebook,
    instagram: storeConfig.socialMedia.instagram,
    twitter: storeConfig.socialMedia.twitter,
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    updateStoreConfig({
      ...storeConfig,
      name: formData.name,
      slogan: formData.slogan,
      description: formData.description,
      logo: formData.logo,
      primaryColor: formData.primaryColor,
      secondaryColor: formData.secondaryColor,
      socialMedia: {
        facebook: formData.facebook,
        instagram: formData.instagram,
        twitter: formData.twitter,
      },
    })

    alert("Configurações salvas com sucesso!")
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Personalização da Loja</h2>
        <p className="text-gray-600">Customize a aparência e informações da sua loja</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Info */}
        <Card>
          <CardHeader>
            <CardTitle>Informações Básicas</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Nome da Loja</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                  required
                />
              </div>

              <div>
                <Label htmlFor="slogan">Slogan</Label>
                <Input
                  id="slogan"
                  value={formData.slogan}
                  onChange={(e) => setFormData((prev) => ({ ...prev, slogan: e.target.value }))}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="description">Descrição "Sobre Nós"</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
                rows={4}
              />
            </div>

            <div>
              <Label htmlFor="logo">URL do Logo</Label>
              <Input
                id="logo"
                value={formData.logo}
                onChange={(e) => setFormData((prev) => ({ ...prev, logo: e.target.value }))}
                placeholder="https://exemplo.com/logo.png"
              />
            </div>
          </CardContent>
        </Card>

        {/* Theme Colors */}
        <Card>
          <CardHeader>
            <CardTitle>Cores do Tema</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="primaryColor">Cor Primária</Label>
                <div className="flex gap-2">
                  <Input
                    id="primaryColor"
                    type="color"
                    value={formData.primaryColor}
                    onChange={(e) => setFormData((prev) => ({ ...prev, primaryColor: e.target.value }))}
                    className="w-16 h-10"
                  />
                  <Input
                    value={formData.primaryColor}
                    onChange={(e) => setFormData((prev) => ({ ...prev, primaryColor: e.target.value }))}
                    placeholder="#3B82F6"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="secondaryColor">Cor Secundária</Label>
                <div className="flex gap-2">
                  <Input
                    id="secondaryColor"
                    type="color"
                    value={formData.secondaryColor}
                    onChange={(e) => setFormData((prev) => ({ ...prev, secondaryColor: e.target.value }))}
                    className="w-16 h-10"
                  />
                  <Input
                    value={formData.secondaryColor}
                    onChange={(e) => setFormData((prev) => ({ ...prev, secondaryColor: e.target.value }))}
                    placeholder="#10B981"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Social Media */}
        <Card>
          <CardHeader>
            <CardTitle>Redes Sociais</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="facebook">Facebook</Label>
              <Input
                id="facebook"
                value={formData.facebook}
                onChange={(e) => setFormData((prev) => ({ ...prev, facebook: e.target.value }))}
                placeholder="https://facebook.com/suapagina"
              />
            </div>

            <div>
              <Label htmlFor="instagram">Instagram</Label>
              <Input
                id="instagram"
                value={formData.instagram}
                onChange={(e) => setFormData((prev) => ({ ...prev, instagram: e.target.value }))}
                placeholder="https://instagram.com/seuusuario"
              />
            </div>

            <div>
              <Label htmlFor="twitter">Twitter</Label>
              <Input
                id="twitter"
                value={formData.twitter}
                onChange={(e) => setFormData((prev) => ({ ...prev, twitter: e.target.value }))}
                placeholder="https://twitter.com/seuusuario"
              />
            </div>
          </CardContent>
        </Card>

        <Button type="submit" className="w-full">
          Salvar Configurações
        </Button>
      </form>
    </div>
  )
}
