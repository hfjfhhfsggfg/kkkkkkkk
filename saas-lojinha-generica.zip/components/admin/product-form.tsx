"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { X, Plus } from "lucide-react"
import { useStore } from "@/lib/store"
import type { Product } from "@/lib/types"

interface ProductFormProps {
  product?: Product | null
  onClose: () => void
}

const PRODUCT_CONDITIONS = ["Novo", "Seminovo", "Usado", "Recondicionado"]
const PRODUCT_TAGS = ["Promoção", "Destaque", "Novidade", "Liquidação", "Oferta", "Exclusivo"]

export function ProductForm({ product, onClose }: ProductFormProps) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    originalPrice: "",
    category: "",
    stock: "",
    featured: false,
    images: [""],
    condition: "Novo",
    brand: "",
    model: "",
    color: "",
    size: "",
    weight: "",
    dimensions: "",
    warranty: "",
    tags: [] as string[],
  })

  const { addProduct, updateProduct, categories } = useStore()

  useEffect(() => {
    if (product) {
      setFormData({
        name: product.name,
        description: product.description,
        price: product.price.toString(),
        originalPrice: product.originalPrice?.toString() || "",
        category: product.category,
        stock: product.stock.toString(),
        featured: product.featured,
        images: product.images.length > 0 ? product.images : [""],
        condition: (product as any).condition || "Novo",
        brand: (product as any).brand || "",
        model: (product as any).model || "",
        color: (product as any).color || "",
        size: (product as any).size || "",
        weight: (product as any).weight || "",
        dimensions: (product as any).dimensions || "",
        warranty: (product as any).warranty || "",
        tags: product.tags || [],
      })
    }
  }, [product])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const productData: Omit<Product, "id"> = {
      name: formData.name,
      description: formData.description,
      price: Number.parseFloat(formData.price),
      originalPrice: formData.originalPrice ? Number.parseFloat(formData.originalPrice) : undefined,
      category: formData.category,
      stock: Number.parseInt(formData.stock),
      featured: formData.featured,
      images: formData.images.filter((img) => img.trim() !== ""),
      tags: formData.tags,
      // Campos extras
      ...(formData.condition && { condition: formData.condition }),
      ...(formData.brand && { brand: formData.brand }),
      ...(formData.model && { model: formData.model }),
      ...(formData.color && { color: formData.color }),
      ...(formData.size && { size: formData.size }),
      ...(formData.weight && { weight: formData.weight }),
      ...(formData.dimensions && { dimensions: formData.dimensions }),
      ...(formData.warranty && { warranty: formData.warranty }),
    }

    if (product) {
      updateProduct(product.id, productData)
    } else {
      addProduct(productData)
    }

    onClose()
  }

  const addImageField = () => {
    setFormData((prev) => ({
      ...prev,
      images: [...prev.images, ""],
    }))
  }

  const updateImage = (index: number, value: string) => {
    setFormData((prev) => ({
      ...prev,
      images: prev.images.map((img, i) => (i === index ? value : img)),
    }))
  }

  const removeImage = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index),
    }))
  }

  const toggleTag = (tag: string) => {
    setFormData((prev) => ({
      ...prev,
      tags: prev.tags.includes(tag) ? prev.tags.filter((t) => t !== tag) : [...prev.tags, tag],
    }))
  }

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{product ? "Editar Produto" : "Novo Produto"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Informações Básicas */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Nome do Produto *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                required
              />
            </div>

            <div>
              <Label htmlFor="category">Categoria *</Label>
              <Select
                value={formData.category}
                onValueChange={(value) => setFormData((prev) => ({ ...prev, category: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione uma categoria" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.name}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Descrição */}
          <div>
            <Label htmlFor="description">Descrição *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
              rows={4}
              required
            />
          </div>

          {/* Preços e Estoque */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="price">Preço (R$) *</Label>
              <Input
                id="price"
                type="number"
                step="0.01"
                value={formData.price}
                onChange={(e) => setFormData((prev) => ({ ...prev, price: e.target.value }))}
                required
              />
            </div>

            <div>
              <Label htmlFor="originalPrice">Preço Original (R$)</Label>
              <Input
                id="originalPrice"
                type="number"
                step="0.01"
                value={formData.originalPrice}
                onChange={(e) => setFormData((prev) => ({ ...prev, originalPrice: e.target.value }))}
                placeholder="Para mostrar desconto"
              />
            </div>

            <div>
              <Label htmlFor="stock">Estoque *</Label>
              <Input
                id="stock"
                type="number"
                value={formData.stock}
                onChange={(e) => setFormData((prev) => ({ ...prev, stock: e.target.value }))}
                required
              />
            </div>

            <div>
              <Label htmlFor="condition">Estado</Label>
              <Select
                value={formData.condition}
                onValueChange={(value) => setFormData((prev) => ({ ...prev, condition: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PRODUCT_CONDITIONS.map((condition) => (
                    <SelectItem key={condition} value={condition}>
                      {condition}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Detalhes do Produto */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="brand">Marca</Label>
              <Input
                id="brand"
                value={formData.brand}
                onChange={(e) => setFormData((prev) => ({ ...prev, brand: e.target.value }))}
              />
            </div>

            <div>
              <Label htmlFor="model">Modelo</Label>
              <Input
                id="model"
                value={formData.model}
                onChange={(e) => setFormData((prev) => ({ ...prev, model: e.target.value }))}
              />
            </div>

            <div>
              <Label htmlFor="color">Cor</Label>
              <Input
                id="color"
                value={formData.color}
                onChange={(e) => setFormData((prev) => ({ ...prev, color: e.target.value }))}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="size">Tamanho</Label>
              <Input
                id="size"
                value={formData.size}
                onChange={(e) => setFormData((prev) => ({ ...prev, size: e.target.value }))}
              />
            </div>

            <div>
              <Label htmlFor="weight">Peso</Label>
              <Input
                id="weight"
                value={formData.weight}
                onChange={(e) => setFormData((prev) => ({ ...prev, weight: e.target.value }))}
                placeholder="Ex: 2kg"
              />
            </div>

            <div>
              <Label htmlFor="dimensions">Dimensões</Label>
              <Input
                id="dimensions"
                value={formData.dimensions}
                onChange={(e) => setFormData((prev) => ({ ...prev, dimensions: e.target.value }))}
                placeholder="Ex: 30x20x10cm"
              />
            </div>

            <div>
              <Label htmlFor="warranty">Garantia</Label>
              <Input
                id="warranty"
                value={formData.warranty}
                onChange={(e) => setFormData((prev) => ({ ...prev, warranty: e.target.value }))}
                placeholder="Ex: 12 meses"
              />
            </div>
          </div>

          {/* Tags */}
          <div>
            <Label>Tags do Produto</Label>
            <div className="flex flex-wrap gap-2 mt-2">
              {PRODUCT_TAGS.map((tag) => (
                <Badge
                  key={tag}
                  variant={formData.tags.includes(tag) ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => toggleTag(tag)}
                >
                  {tag}
                </Badge>
              ))}
            </div>
          </div>

          {/* Produto em Destaque */}
          <div className="flex items-center space-x-2">
            <Switch
              id="featured"
              checked={formData.featured}
              onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, featured: checked }))}
            />
            <Label htmlFor="featured">Produto em destaque na página inicial</Label>
          </div>

          {/* Imagens */}
          <div>
            <Label>Imagens do Produto</Label>
            <div className="space-y-2 mt-2">
              {formData.images.map((image, index) => (
                <div key={index} className="flex gap-2">
                  <Input
                    placeholder="URL da imagem"
                    value={image}
                    onChange={(e) => updateImage(index, e.target.value)}
                  />
                  {formData.images.length > 1 && (
                    <Button type="button" variant="outline" size="sm" onClick={() => removeImage(index)}>
                      <X className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              ))}
              <Button type="button" variant="outline" onClick={addImageField} className="w-full bg-transparent">
                <Plus className="w-4 h-4 mr-2" />
                Adicionar Imagem
              </Button>
            </div>
          </div>

          {/* Botões */}
          <div className="flex justify-end space-x-2 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit">{product ? "Atualizar" : "Criar"} Produto</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
