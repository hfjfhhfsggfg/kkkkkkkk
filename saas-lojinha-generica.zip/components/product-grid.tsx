import Link from "next/link"
import { ProductCard } from "@/components/product-card"
import type { Product } from "@/lib/types"

interface ProductGridProps {
  products: Product[]
  title?: string
}

export function ProductGrid({ products, title }: ProductGridProps) {
  if (products.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Nenhum produto encontrado.</p>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {title && (
        <div className="text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">{title}</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-yellow-600 to-yellow-500 mx-auto rounded-full"></div>
        </div>
      )}

      {/* Grid MELHORADO - Mais espaçamento e responsivo */}
      <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6 lg:gap-8">
        {products.map((product) => (
          <Link
            key={product.id}
            href={`/produto/${product.id}`}
            className="block group hover:scale-105 transition-transform duration-200"
          >
            <ProductCard product={product} />
          </Link>
        ))}
      </div>
    </div>
  )
}
