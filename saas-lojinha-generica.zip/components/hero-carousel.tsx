"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"
import type { Product } from "@/lib/types"
import { formatPrice } from "@/lib/utils"

interface HeroCarouselProps {
  products: Product[]
}

export function HeroCarousel({ products }: HeroCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex === products.length - 1 ? 0 : prevIndex + 1))
    }, 5000)

    return () => clearInterval(timer)
  }, [products.length])

  const goToPrevious = () => {
    setCurrentIndex(currentIndex === 0 ? products.length - 1 : currentIndex - 1)
  }

  const goToNext = () => {
    setCurrentIndex(currentIndex === products.length - 1 ? 0 : currentIndex + 1)
  }

  if (products.length === 0) return null

  const currentProduct = products[currentIndex]

  return (
    <div className="relative bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg overflow-hidden">
      <div className="grid md:grid-cols-2 gap-8 p-8 md:p-12">
        <div className="flex flex-col justify-center text-white">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">{currentProduct.name}</h2>
          <p className="text-lg mb-6 opacity-90">{currentProduct.description}</p>
          <div className="flex items-center gap-4 mb-6">
            <span className="text-2xl font-bold">{formatPrice(currentProduct.price)}</span>
            {currentProduct.originalPrice && (
              <span className="text-lg line-through opacity-75">{formatPrice(currentProduct.originalPrice)}</span>
            )}
          </div>
          <Button className="bg-white text-blue-600 hover:bg-gray-100 w-fit">Ver Produto</Button>
        </div>

        <div className="relative aspect-square">
          <Image
            src={currentProduct.images[0] || "/placeholder.svg?height=400&width=400"}
            alt={currentProduct.name}
            fill
            className="object-cover rounded-lg"
          />
        </div>
      </div>

      {/* Navigation Buttons */}
      <Button
        variant="ghost"
        size="sm"
        className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/20 hover:bg-white/30 text-white"
        onClick={goToPrevious}
      >
        <ChevronLeft className="w-5 h-5" />
      </Button>

      <Button
        variant="ghost"
        size="sm"
        className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/20 hover:bg-white/30 text-white"
        onClick={goToNext}
      >
        <ChevronRight className="w-5 h-5" />
      </Button>

      {/* Indicators */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
        {products.map((_, index) => (
          <button
            key={index}
            className={`w-2 h-2 rounded-full transition-colors ${index === currentIndex ? "bg-white" : "bg-white/50"}`}
            onClick={() => setCurrentIndex(index)}
          />
        ))}
      </div>
    </div>
  )
}
