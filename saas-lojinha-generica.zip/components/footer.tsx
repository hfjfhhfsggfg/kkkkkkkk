"use client"

import { Facebook, Instagram, Twitter } from "lucide-react"
import { useStore } from "@/lib/store"

interface FooterProps {
  onAdminClick: () => void
}

export function Footer({ onAdminClick }: FooterProps) {
  const { storeConfig } = useStore()

  return (
    <footer className="bg-gray-900 text-white relative">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">{storeConfig.name}</h3>
            <p className="text-gray-400 text-sm leading-relaxed">
              {storeConfig.description ||
                "Os melhores produtos com qualidade e preços incríveis. Compre direto pelo WhatsApp!"}
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Links Rápidos</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#produtos" className="text-gray-400 hover:text-white transition-colors">
                  Produtos
                </a>
              </li>
              <li>
                <a href="#categorias" className="text-gray-400 hover:text-white transition-colors">
                  Categorias
                </a>
              </li>
              <li>
                <a href="#sobre" className="text-gray-400 hover:text-white transition-colors">
                  Sobre
                </a>
              </li>
              <li>
                <button
                  onClick={() => {
                    const message = "Olá! Gostaria de mais informações."
                    const whatsappUrl = `https://wa.me/${storeConfig.whatsapp}?text=${encodeURIComponent(message)}`
                    window.open(whatsappUrl, "_blank")
                  }}
                  className="text-gray-400 hover:text-white transition-colors text-left"
                >
                  Contato
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Políticas</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  Política de Privacidade
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  Termos de Uso
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  Trocas e Devoluções
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Redes Sociais</h3>
            <div className="flex space-x-4">
              {storeConfig.socialMedia.facebook && (
                <a
                  href={storeConfig.socialMedia.facebook}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <Facebook className="w-5 h-5" />
                </a>
              )}
              {storeConfig.socialMedia.instagram && (
                <a
                  href={storeConfig.socialMedia.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <Instagram className="w-5 h-5" />
                </a>
              )}
              {storeConfig.socialMedia.twitter && (
                <a
                  href={storeConfig.socialMedia.twitter}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <Twitter className="w-5 h-5" />
                </a>
              )}
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            © {new Date().getFullYear()} {storeConfig.name}. Todos os direitos reservados.
          </p>

          {/* Botão Admin bem escondido no final do rodapé */}
          <div className="mt-4 md:mt-0">
            <button
              onClick={onAdminClick}
              className="text-gray-600 hover:text-gray-400 text-xs opacity-30 hover:opacity-60 transition-all duration-300"
              style={{ fontSize: "10px" }}
            >
              •••
            </button>
          </div>
        </div>
      </div>
    </footer>
  )
}
