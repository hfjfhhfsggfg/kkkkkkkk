"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"
import type { Product, Category, Order, CartItem, StoreConfig, Banner } from "./types"

interface StoreState {
  // Authentication
  isAuthenticated: boolean
  login: () => void
  logout: () => void

  // Products
  products: Product[]
  categories: Category[]
  addProduct: (product: Omit<Product, "id">) => void
  updateProduct: (id: string, product: Omit<Product, "id">) => void
  deleteProduct: (id: string) => void
  searchProducts: (query: string) => void

  // Cart
  cart: CartItem[]
  isCartOpen: boolean
  addToCart: (product: Product, quantity: number) => void
  updateCartItemQuantity: (productId: string, quantity: number) => void
  removeFromCart: (productId: string) => void
  toggleCart: () => void
  clearCart: () => void

  // Orders
  orders: Order[]
  addOrder: (order: Omit<Order, "id">) => void
  updateOrderStatus: (orderId: string, status: Order["status"]) => void

  // Store Configuration
  storeConfig: StoreConfig
  updateStoreConfig: (config: StoreConfig) => void

  // Banners
  banners: Banner[]
  addBanner: (banner: Omit<Banner, "id">) => void
  updateBanner: (id: string, banner: Omit<Banner, "id">) => void
  deleteBanner: (id: string) => void

  // Initialization
  loadInitialData: () => void
}

const initialProducts: Product[] = [
  {
    id: "1",
    name: "iPhone 16 PRO MAX (2024)",
    description: "O mais avançado iPhone com chip A18 Pro, câmera de 48MP e tela Super Retina XDR de 6.9 polegadas.",
    price: 7299.0,
    originalPrice: 9099.0,
    category: "Eletrônicos",
    stock: 25,
    featured: true,
    images: ["/placeholder.svg?height=400&width=400"],
    colors: "4",
  },
  {
    id: "2",
    name: "Samsung Galaxy S24 Ultra",
    description: "Smartphone premium com S Pen integrada, câmera de 200MP e tela Dynamic AMOLED 2X.",
    price: 5999.0,
    originalPrice: 7499.0,
    category: "Eletrônicos",
    stock: 15,
    featured: true,
    images: ["/placeholder.svg?height=400&width=400"],
    colors: "5",
  },
  {
    id: "3",
    name: "MacBook Air M3",
    description: "Notebook ultrafino com chip M3, tela Liquid Retina de 13.6 polegadas e até 18 horas de bateria.",
    price: 8999.0,
    originalPrice: 10999.0,
    category: "Eletrônicos",
    stock: 8,
    featured: true,
    images: ["/placeholder.svg?height=400&width=400"],
    colors: "4",
  },
  {
    id: "4",
    name: "AirPods Pro (3ª geração)",
    description: "Fones de ouvido sem fio com cancelamento ativo de ruído e áudio espacial personalizado.",
    price: 1899.0,
    originalPrice: 2299.0,
    category: "Eletrônicos",
    stock: 30,
    featured: false,
    images: ["/placeholder.svg?height=400&width=400"],
  },
]

const initialCategories: Category[] = [
  { id: "1", name: "Eletrônicos", productCount: 4 },
  { id: "2", name: "Smartphones", productCount: 2 },
  { id: "3", name: "Notebooks", productCount: 1 },
  { id: "4", name: "Acessórios", productCount: 1 },
  { id: "5", name: "Casa", productCount: 0 },
]

const initialOrders: Order[] = [
  {
    id: "1",
    customerName: "João Silva",
    customerPhone: "11999999999",
    customerEmail: "joao@email.com",
    items: [{ name: "iPhone 16 PRO MAX (2024)", quantity: 1, price: 7299.0 }],
    total: 7299.0,
    status: "pending",
    createdAt: new Date().toISOString(),
  },
  {
    id: "2",
    customerName: "Maria Santos",
    customerPhone: "11888888888",
    customerEmail: "maria@email.com",
    items: [{ name: "AirPods Pro (3ª geração)", quantity: 2, price: 1899.0 }],
    total: 3798.0,
    status: "confirmed",
    createdAt: new Date().toISOString(),
  },
]

const initialBanners: Banner[] = [
  {
    id: "1",
    title: "Lançamentos Apple 2024",
    description: "Conheça os novos iPhone 16, MacBook Air M3 e muito mais com descontos especiais",
    image: "/placeholder.svg?height=400&width=800",
    link: "#produtos",
    buttonText: "Ver Produtos",
    order: 0,
  },
  {
    id: "2",
    title: "Mega Promoção Eletrônicos",
    description: "Descontos de até 30% em smartphones, notebooks e acessórios selecionados",
    image: "/placeholder.svg?height=400&width=800",
    link: "#produtos",
    buttonText: "Aproveitar Oferta",
    order: 1,
  },
]

const initialStoreConfig: StoreConfig = {
  name: "TechStore",
  slogan: "Tecnologia de ponta com os melhores preços",
  description:
    "Somos especialistas em tecnologia, oferecendo os melhores produtos eletrônicos com qualidade garantida e preços competitivos. Sua satisfação é nossa prioridade.",
  logo: "",
  primaryColor: "#3B82F6",
  secondaryColor: "#F97316",
  whatsapp: "5511999999999",
  email: "contato@techstore.com",
  socialMedia: {
    facebook: "",
    instagram: "",
    twitter: "",
  },
  returnPolicy: "Você tem até 7 dias para trocar ou devolver o produto. O produto deve estar em perfeitas condições.",
  paymentMethods: "Aceitamos Pix, Boleto Bancário e Cartão de Crédito em até 12x.",
  emailNotifications: true,
}

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      // Authentication
      isAuthenticated: false,
      login: () => set({ isAuthenticated: true }),
      logout: () => set({ isAuthenticated: false }),

      // Products
      products: [],
      categories: [],
      addProduct: (product) => {
        const newProduct: Product = {
          ...product,
          id: Date.now().toString(),
        }
        set((state) => ({
          products: [...state.products, newProduct],
        }))
      },
      updateProduct: (id, product) => {
        set((state) => ({
          products: state.products.map((p) => (p.id === id ? { ...product, id } : p)),
        }))
      },
      deleteProduct: (id) => {
        set((state) => ({
          products: state.products.filter((p) => p.id !== id),
        }))
      },
      searchProducts: (query) => {
        console.log("Searching for:", query)
      },

      // Cart
      cart: [],
      isCartOpen: false,
      addToCart: (product, quantity) => {
        set((state) => {
          const existingItem = state.cart.find((item) => item.product.id === product.id)

          if (existingItem) {
            return {
              cart: state.cart.map((item) =>
                item.product.id === product.id ? { ...item, quantity: item.quantity + quantity } : item,
              ),
            }
          } else {
            return {
              cart: [...state.cart, { product, quantity }],
            }
          }
        })
      },
      updateCartItemQuantity: (productId, quantity) => {
        if (quantity <= 0) {
          get().removeFromCart(productId)
          return
        }

        set((state) => ({
          cart: state.cart.map((item) => (item.product.id === productId ? { ...item, quantity } : item)),
        }))
      },
      removeFromCart: (productId) => {
        set((state) => ({
          cart: state.cart.filter((item) => item.product.id !== productId),
        }))
      },
      toggleCart: () => {
        set((state) => ({ isCartOpen: !state.isCartOpen }))
      },
      clearCart: () => {
        set({ cart: [] })
      },

      // Orders
      orders: [],
      addOrder: (order) => {
        const newOrder: Order = {
          ...order,
          id: Date.now().toString(),
        }
        set((state) => ({
          orders: [...state.orders, newOrder],
        }))
      },
      updateOrderStatus: (orderId, status) => {
        set((state) => ({
          orders: state.orders.map((order) => (order.id === orderId ? { ...order, status } : order)),
        }))
      },

      // Store Configuration
      storeConfig: initialStoreConfig,
      updateStoreConfig: (config) => {
        set({ storeConfig: config })
      },

      // Banners
      banners: [],
      addBanner: (banner) => {
        const newBanner: Banner = {
          ...banner,
          id: Date.now().toString(),
        }
        set((state) => ({
          banners: [...state.banners, newBanner],
        }))
      },
      updateBanner: (id, banner) => {
        set((state) => ({
          banners: state.banners.map((b) => (b.id === id ? { ...banner, id } : b)),
        }))
      },
      deleteBanner: (id) => {
        set((state) => ({
          banners: state.banners.filter((b) => b.id !== id),
        }))
      },

      // Initialization
      loadInitialData: () => {
        const state = get()
        if (state.banners.length === 0) {
          set({
            products: initialProducts,
            categories: initialCategories,
            orders: initialOrders,
            banners: initialBanners,
          })
        }
      },
    }),
    {
      name: "lojinha-storage",
      partialize: (state) => ({
        products: state.products,
        categories: state.categories,
        orders: state.orders,
        storeConfig: state.storeConfig,
        isAuthenticated: state.isAuthenticated,
        banners: state.banners,
      }),
    },
  ),
)
