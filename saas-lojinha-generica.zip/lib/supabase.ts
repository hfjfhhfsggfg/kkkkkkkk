import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  realtime: {
    params: {
      eventsPerSecond: 10,
    },
  },
})

// Tipos do banco de dados
export interface ChatConversation {
  id: string
  customer_name: string
  customer_phone?: string
  customer_email?: string
  status: "active" | "closed" | "archived"
  last_message_at: string
  created_at: string
  updated_at: string
}

export interface ChatMessage {
  id: string
  conversation_id: string
  message: string
  is_from_customer: boolean
  sender_name?: string
  read_by_admin: boolean
  read_by_customer: boolean
  created_at: string
}

export interface Product {
  id: string
  name: string
  description: string
  price: number
  original_price?: number
  category_id: string
  stock: number
  featured: boolean
  images: string[]
  tags: string[]
  condition?: string
  brand?: string
  model?: string
  color?: string
  size?: string
  weight?: string
  dimensions?: string
  warranty?: string
  created_at: string
  updated_at: string
}

export interface Category {
  id: string
  name: string
  description?: string
  created_at: string
  updated_at: string
}

export interface Banner {
  id: string
  title: string
  description?: string
  image: string
  link?: string
  button_text?: string
  order_index: number
  active: boolean
  created_at: string
  updated_at: string
}

export interface StoreConfig {
  id: string
  name: string
  slogan?: string
  description?: string
  logo?: string
  primary_color: string
  secondary_color: string
  whatsapp: string
  email?: string
  facebook?: string
  instagram?: string
  twitter?: string
  return_policy?: string
  payment_methods?: string
  email_notifications: boolean
  created_at: string
  updated_at: string
}
