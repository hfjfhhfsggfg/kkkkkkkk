// Sistema de dados local para funcionar sem backend
export interface ChatMessage {
  id: string
  conversationId: string
  message: string
  isFromCustomer: boolean
  senderName: string
  timestamp: string
  readByAdmin: boolean
  readByCustomer: boolean
}

export interface ChatConversation {
  id: string
  customerName: string
  customerPhone?: string
  customerEmail?: string
  status: "active" | "closed"
  lastMessageAt: string
  createdAt: string
}

class LocalStorageDB {
  private getItem<T>(key: string, defaultValue: T): T {
    if (typeof window === "undefined") return defaultValue

    try {
      const item = localStorage.getItem(key)
      return item ? JSON.parse(item) : defaultValue
    } catch {
      return defaultValue
    }
  }

  private setItem<T>(key: string, value: T): void {
    if (typeof window === "undefined") return

    try {
      localStorage.setItem(key, JSON.stringify(value))
    } catch (error) {
      console.error("Erro ao salvar no localStorage:", error)
    }
  }

  // Conversas
  getConversations(): ChatConversation[] {
    return this.getItem("chat_conversations", [])
  }

  saveConversation(conversation: ChatConversation): void {
    const conversations = this.getConversations()
    const existingIndex = conversations.findIndex((c) => c.id === conversation.id)

    if (existingIndex >= 0) {
      conversations[existingIndex] = conversation
    } else {
      conversations.push(conversation)
    }

    this.setItem("chat_conversations", conversations)
  }

  // Mensagens
  getMessages(conversationId: string): ChatMessage[] {
    const allMessages = this.getItem<ChatMessage[]>("chat_messages", [])
    return allMessages.filter((msg) => msg.conversationId === conversationId)
  }

  saveMessage(message: ChatMessage): void {
    const messages = this.getItem<ChatMessage[]>("chat_messages", [])
    messages.push(message)
    this.setItem("chat_messages", messages)
  }

  updateMessage(messageId: string, updates: Partial<ChatMessage>): void {
    const messages = this.getItem<ChatMessage[]>("chat_messages", [])
    const messageIndex = messages.findIndex((m) => m.id === messageId)

    if (messageIndex >= 0) {
      messages[messageIndex] = { ...messages[messageIndex], ...updates }
      this.setItem("chat_messages", messages)
    }
  }

  // Mensagens não lidas
  getUnreadCount(conversationId: string): number {
    const messages = this.getMessages(conversationId)
    return messages.filter((msg) => !msg.isFromCustomer && !msg.readByCustomer).length
  }

  // Limpar dados (para desenvolvimento)
  clearAllData(): void {
    if (typeof window === "undefined") return
    localStorage.removeItem("chat_conversations")
    localStorage.removeItem("chat_messages")
  }
}

export const localDB = new LocalStorageDB()
