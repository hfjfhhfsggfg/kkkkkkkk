export interface Product {
  id: string
  name: string
  description: string
  price: number
  originalPrice?: number
  category: string
  stock: number
  featured: boolean
  images: string[]
  tags?: string[]
}

export interface Category {
  id: string
  name: string
  productCount: number
}

export interface CartItem {
  product: Product
  quantity: number
}

export interface Order {
  id: string
  customerName: string
  customerPhone: string
  customerEmail?: string
  items: Array<{
    name: string
    quantity: number
    price: number
  }>
  total: number
  status: "pending" | "confirmed" | "shipped" | "delivered" | "cancelled"
  createdAt: string
}

export interface StoreConfig {
  name: string
  slogan: string
  description: string
  logo: string
  primaryColor: string
  secondaryColor: string
  whatsapp: string
  email: string
  socialMedia: {
    facebook: string
    instagram: string
    twitter: string
  }
  returnPolicy: string
  paymentMethods: string
  emailNotifications: boolean
}

export interface Banner {
  id: string
  title: string
  description: string
  image: string
  link?: string
  buttonText?: string
  order: number
}
