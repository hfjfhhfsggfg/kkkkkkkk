-- Criar extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Tabela de configurações da loja
CREATE TABLE IF NOT EXISTS store_config (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  slogan TEXT,
  description TEXT,
  logo TEXT,
  primary_color VARCHAR(7) DEFAULT '#3B82F6',
  secondary_color VARCHAR(7) DEFAULT '#F97316',
  whatsapp VARCHAR(20) NOT NULL,
  email VARCHAR(255),
  facebook TEXT,
  instagram TEXT,
  twitter TEXT,
  return_policy TEXT,
  payment_methods TEXT,
  email_notifications BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de categorias
CREATE TABLE IF NOT EXISTS categories (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de produtos
CREATE TABLE IF NOT EXISTS products (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  original_price DECIMAL(10,2),
  category_id UUID REFERENCES categories(id),
  stock INTEGER NOT NULL DEFAULT 0,
  featured BOOLEAN DEFAULT false,
  images TEXT[] DEFAULT '{}',
  tags TEXT[] DEFAULT '{}',
  condition VARCHAR(50) DEFAULT 'Novo',
  brand VARCHAR(255),
  model VARCHAR(255),
  color VARCHAR(100),
  size VARCHAR(100),
  weight VARCHAR(100),
  dimensions VARCHAR(100),
  warranty VARCHAR(100),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de banners
CREATE TABLE IF NOT EXISTS banners (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  image TEXT NOT NULL,
  link TEXT,
  button_text VARCHAR(100),
  order_index INTEGER DEFAULT 0,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de conversas de chat
CREATE TABLE IF NOT EXISTS chat_conversations (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  customer_name VARCHAR(255) NOT NULL,
  customer_phone VARCHAR(20),
  customer_email VARCHAR(255),
  status VARCHAR(20) DEFAULT 'active', -- active, closed, archived
  last_message_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de mensagens do chat
CREATE TABLE IF NOT EXISTS chat_messages (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  conversation_id UUID REFERENCES chat_conversations(id) ON DELETE CASCADE,
  message TEXT NOT NULL,
  is_from_customer BOOLEAN NOT NULL DEFAULT true,
  sender_name VARCHAR(255),
  read_by_admin BOOLEAN DEFAULT false,
  read_by_customer BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de pedidos
CREATE TABLE IF NOT EXISTS orders (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  customer_name VARCHAR(255) NOT NULL,
  customer_phone VARCHAR(20) NOT NULL,
  customer_email VARCHAR(255),
  items JSONB NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  status VARCHAR(20) DEFAULT 'pending', -- pending, confirmed, shipped, delivered, cancelled
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_featured ON products(featured);
CREATE INDEX IF NOT EXISTS idx_chat_messages_conversation ON chat_messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_created_at ON chat_messages(created_at);
CREATE INDEX IF NOT EXISTS idx_chat_conversations_status ON chat_conversations(status);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);

-- Inserir dados iniciais se não existirem
INSERT INTO store_config (name, slogan, whatsapp, email) 
SELECT 'TechStore', 'Tecnologia de ponta com os melhores preços', '5511999999999', 'contato@techstore.com'
WHERE NOT EXISTS (SELECT 1 FROM store_config);

-- Inserir categorias iniciais
INSERT INTO categories (name, description) VALUES
('Eletrônicos', 'Smartphones, tablets, notebooks e acessórios'),
('Smartphones', 'Os melhores smartphones do mercado'),
('Notebooks', 'Notebooks para trabalho e jogos'),
('Acessórios', 'Fones, capas, carregadores e mais')
ON CONFLICT DO NOTHING;

-- Habilitar RLS (Row Level Security)
ALTER TABLE chat_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE banners ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE store_config ENABLE ROW LEVEL SECURITY;

-- Políticas de segurança (permitir leitura pública, escrita autenticada)
CREATE POLICY "Allow public read access" ON products FOR SELECT USING (true);
CREATE POLICY "Allow public read access" ON categories FOR SELECT USING (true);
CREATE POLICY "Allow public read access" ON banners FOR SELECT USING (true);
CREATE POLICY "Allow public read access" ON store_config FOR SELECT USING (true);
CREATE POLICY "Allow public read access" ON chat_conversations FOR SELECT USING (true);
CREATE POLICY "Allow public read access" ON chat_messages FOR SELECT USING (true);

CREATE POLICY "Allow public insert access" ON chat_conversations FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public insert access" ON chat_messages FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public insert access" ON orders FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public update access" ON chat_conversations FOR UPDATE USING (true);
CREATE POLICY "Allow public update access" ON chat_messages FOR UPDATE USING (true);
